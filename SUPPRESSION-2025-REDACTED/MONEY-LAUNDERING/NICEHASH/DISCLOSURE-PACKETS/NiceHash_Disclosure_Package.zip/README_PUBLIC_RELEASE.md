# PUBLIC RELEASE INSTRUCTIONS

This package contains forensic evidence and documentation of a large-scale systemic exploit involving NiceHash and partner mining pools. 
It is to be released to journalists, developers, and regulators in the event that the originator is silenced or incapacitated.

## SHA256 Checksum Verification
Before opening any files, verify the integrity of this package.

## Who Should Receive This:
- Select journalists (Laura Shin, Amy Castor, David Gerard)
- MIT DCI or Cornell IC3
- Whistleblower channels (SEC, EU tech fraud)

## Notes:
This evidence has been cross-referenced, time-logged, and verified against blockchain data and API returns.